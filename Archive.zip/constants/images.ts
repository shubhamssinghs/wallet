import NOTRANSACTION from "@/assets/images/no-transaction.png";
import TRANSACTIONPLACEHOLDER from "@/assets/images/transaction-hero-image.png";
import SETTINGPLACEHOLDER from "@/assets/images/setting-hero-image.png";

export default { NOTRANSACTION, TRANSACTIONPLACEHOLDER, SETTINGPLACEHOLDER };
