import { colors } from "./Colors";
import icons from "./icons";
import images from "./images";

export default { colors, icons, images };
