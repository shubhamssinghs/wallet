// src/@types/images.d.ts

declare module "*.png" {
  const value: any;
  export default value;
}
